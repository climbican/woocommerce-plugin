<?php

namespace App\Http\Controllers\Api;

class WooFields {
    // base variabes
    var $type = 'variable';
    var $sku = '';
    var $name = '';
    var $published = 1;
    var $is_featured = 0;
    var $visibility_in_catalog = 1;
    var $short_description = 0;
    // is in stock 0 | 1
    var $in_stock = 1;
    //current stock level
    var $stock = 0;
    var $weight = '';
    var $length = '';
    var $width = '';
    var $height = '';
    var $categories = 'RIMS';
    var $images = '';
    var $parent = '';
    var $regular_price = '';
    var $active = '';
    // attribute 1
    var $attribute_1_name = 'Size';
    var $attribute_1_value = 1;
    var $attribute_1_global = 1;
    var $attribute_1_visible = 1;
    // attribute 2
    var $attribute_2_name = 'Bolt Pattern';
    var $attribute_2_value = 1;
    var $attribute_2_global = 1;
    var $attribute_2_visible = 1;
    // attribute 3
    var $attribute_3_name = 'Rim Offset';
    var $attribute_3_value = 1;
    var $attribute_3_global = 1;
    var $attribute_3_visible = 1;
    // attribute 4
    var $attribute_4_name = 'Lug Count';
    var $attribute_4_value = 1;
    var $attribute_4_global = 1;
    var $attribute_4_visible = 1;
    // attribute 5
    var $attribute_5_name = 'Hub Bore';
    var $attribute_5_value = 1;
    var $attribute_5_global = 1;
    var $attribute_5_visible = 1;
    // attribute 6
    var $attribute_6_name = 'Load Rating';
    var $attribute_6_value = 1;
    var $attribute_6_global = 1;
    var $attribute_6_visible = 1;
    // attribute 7
    var $attribute_7_name = 'Finish';
    var $attribute_7_value = 1;
    var $attribute_7_global = 1;
    var $attribute_7_visible = 1;
}
