<?php
/*
|--------------------------------------------------------------------------
| IMPORT AND CONVERT H.O. TIRES INVENTORY FROM VENDORS
|--------------------------------------------------------------------------
|
|
|
 * Name: HORimImportConvsionController.php
 *
 * Description: There are several vendors and each has an inventory sheet that is a little different.  So each requires a little different processing to
 * import into WooCommerce
 *
 *
 * Copyright (c) 2021. All Code is the property of Ledgedog unless unless otherwise specified by contract.
 *
 *          (\ /)
 *          (O .o)
 *          (> "<)
 *          (_/\_)
 *      ]) o 0 []v[]
 *
 *
 *
 * @author Michael Rumack
 * @company Ledgedog
 * User: climbican
 * Date: 2/5/16
 * Time: 2:35 PM
 * Last Mod:
 * Notes:
 *
 * current vendors are as follows
 *
 * ATD
 * WheelPros
 * can't remember...
 *
 *
 *
 * TODO: NEXT STEP IS THE FIELD MAPPING FROM ATD TO WOOCOMMERCE FIELDS
 *
 */
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Api\WooCommerceWheelImport;
use App\Http\Controllers\Api\WooFields;

class HORimImportConversionController extends Controller {

    var $csv_file = null;

    var $sources = ['atd', 'wheelpros', 'ace'];
    var $has_errors = false;
    private $vendor_column_names;
    private $wcm_column_names;
    private $raw_array_in;
    private array $output_array = [];
    private $product_name_field_reference = '';

    function __construct() {}


    public function run_processing() {

        // this will use a request param
        $this->wcw = new WooCommerceWheelImport('atd');
        $this->wcm_column_names = $this->wcw->get_wcm_column_names();
        $this->vendor_column_names = $this->wcw->get_vendor_column_names();
        // name field is the one used to determine if the product group has changed
        $this->product_name_field_reference = $this->wcw->get_reference_name_field();

        $this->raw_array_in = $this->csv_to_array('/Applications/MAMP/htdocs/ledgedog.com/wheel-import/ATD-MAP.csv');

        $this->map_data_to_woocommerce();
    }

    private function read_csv_file() {
        $this->csv_file = fopen('/Applications/MAMP/htdocs/ledgedog.com/wheel-import/ATD-MAP.csv', "r+");
    }

    /**
     * @param $file
     * @param string $source_name
     *
     * NOTES:
     *  loop through each ROW of the raw array
     *  loop through all keys to get the values for the array
     *
     * TODO: THIS IS WHERE I LEFT OFF
     *
     * TODO: account for active as in active or not deactivated product
     *
     *
     *
     * to start I have three different column name sets>..
     *
     * Woocommerce field names <<< intermediary and holder for commonGround -- >>> WooFields <<<< Vendor fields
     *
     *
     *
     *
     *  [Status (US)] => Active
     */
    function map_data_to_woocommerce() {
        $reference_column_names = new WooFields();
        $holder_position = 0;
        $product_name = '';
        $row_to_add = [];
        $row_to_add_loading = false;
        // // need a state to guide what step to take
        $count = count($this->raw_array_in);
        for($j=0; $j < $count; $j++) {
            // this covers the first iteration only!
            if($product_name !== $this->raw_array_in[$j][$this->product_name_field_reference] && $product_name === '') {
                $product_name = $this->raw_array_in[$j][$this->product_name_field_reference];
                $row_to_add = $this->raw_array_in[$j];
            }
            else {
                // is the same product --->>>> generate parent row to append
                // // go through attributes add | "space" new value
                if($product_name === $this->raw_array_in[$j][$this->product_name_field_reference]) {
                    // now generate parent row
                    if($row_to_add_loading) {
                        // load parent row values
                        for($k=0; $k<7; $k++){
                            // set attribute name first
                            $field_name = 'attribute_'.($k+1).'_name';
                            if($k === 0 ) {
                                $row_to_add[$this->vendor_column_names->$field_name] = $this->vendor_column_names ;
                            }
                            $field_value_name = 'attribute_'.($k+1).'_value';
                            // make sure the value isn't already in the field
                            if(!preg_match('/'.$this->raw_array_in[$j][$field_value_name].'/', $row_to_add[$this->vendor_column_names->$field_value_name])) {
                                $row_to_add[$this->vendor_column_names->$field_value_name] = $row_to_add[$this->vendor_column_names->$field_value_name] . ',' . $this->raw_array_in[$j][$field_value_name];
                            }
                            if($k === 6) {
                                // append the parent row to output array
                                // set $j to start number
                                array_push($this->output_array, $row_to_add);
                                $row_to_add = [];
                                $j = $holder_position;
                            }

                        }
                    }
                    else {
                        $holder_position = $j;

                    }
                }
                else {
                    // new product
                    // // reset $j to $holder position to load all child products
                    // // // append parent row to out array
                    // // // load new product name and parent row
                }


            }

        } // end for loop going through all records





        array_unshift($this->output_array, $this->wcw->get_woocommerce_name_array());

        echo 'this is the first attempt<br>';
        print_r($this->output_array);


        exit();
    }


    private final function process_row($row_id): WooFields {
        $woo = new WooFields();
        $reference_column_names = new WooFields();
        foreach($reference_column_names as $key=>$value){
            if( isset($this->raw_array_in[$row_id][$this->vendor_column_names->$key])) {
                if ( $this->wcw->has_set_value($key, $this->vendor_column_names->$key) ) {
                    $woo->$key = $this->raw_array_in[$row_id][$this->vendor_column_names->$key];
                }
            }
        }
        return $woo;
    }





    private final function out_file_csv(): void {
        $file_name = $this->sources[0] . '_' .time().'.csv';
        $fp = fopen('php://output', 'w'); // this sends the file directly to client once completed
        // // fopen('file.csv', 'w');

        foreach ($this->output_array as $fields) {
            fputcsv($fp, $fields);
        }

        fclose($fp);
    }

    /**
     * @desc convert a csv file to an associative array!
     *
     * @param string $filename
     * @param string $delimiter
     * @return array|false
     */
    function csv_to_array(string $filename='', string $delimiter=','): array {
        if(!file_exists($filename) || !is_readable($filename))
            return FALSE;

        $header = NULL;
        $data = array();
        if (($handle = fopen($filename, 'r')) !== FALSE)
        {
            while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE)
            {
                if(!$header)
                    $header = $row;
                else
                    $data[] = array_combine($header, $row);
            }
            fclose($handle);
        }
        return $data;
    }












    /**
     * @param $fh
     * @param array $fields
     * @param string $delimiter
     * @param string $enclosure
     * @param false $mysql_null
     *
     * Use this if csvout fails
     */
    function fputcsv2 ($fh, array $fields, $delimiter = ',', $enclosure = '"', $mysql_null = false) {
        $delimiter_esc = preg_quote($delimiter, '/');
        $enclosure_esc = preg_quote($enclosure, '/');

        $output = array();
        foreach ($fields as $field) {
            if ($field === null && $mysql_null) {
                $output[] = 'NULL';
                continue;
            }

            $output[] = preg_match("/(?:${delimiter_esc}|${enclosure_esc}|\s)/", $field) ? (
                $enclosure . str_replace($enclosure, $enclosure . $enclosure, $field) . $enclosure
            ) : $field;
        }

        fwrite($fh, join($delimiter, $output) . "\n");
    }

    /**
     * @param $filepath
     * @param $data
     * @param array $header
     * @return bool
     *
     * MS safe csv
     */
    function mssafe_csv($filepath, $data, $header = array()){
        if ( $fp = fopen($filepath, 'w') ) {
            $show_header = true;
            if ( empty($header) ) {
                $show_header = false;
                reset($data);
                $line = current($data);
                if ( !empty($line) ) {
                    reset($line);
                    $first = current($line);
                    if ( substr($first, 0, 2) == 'ID' && !preg_match('/["\\s,]/', $first) ) {
                        array_shift($data);
                        array_shift($line);
                        if ( empty($line) ) {
                            fwrite($fp, "\"{$first}\"\r\n");
                        } else {
                            fwrite($fp, "\"{$first}\",");
                            fputcsv($fp, $line);
                            fseek($fp, -1, SEEK_CUR);
                            fwrite($fp, "\r\n");
                        }
                    }
                }
            } else {
                reset($header);
                $first = current($header);
                if ( substr($first, 0, 2) == 'ID' && !preg_match('/["\\s,]/', $first) ) {
                    array_shift($header);
                    if ( empty($header) ) {
                        $show_header = false;
                        fwrite($fp, "\"{$first}\"\r\n");
                    } else {
                        fwrite($fp, "\"{$first}\",");
                    }
                }
            }
            if ( $show_header ) {
                fputcsv($fp, $header);
                fseek($fp, -1, SEEK_CUR);
                fwrite($fp, "\r\n");
            }
            foreach ( $data as $line ) {
                fputcsv($fp, $line);
                fseek($fp, -1, SEEK_CUR);
                fwrite($fp, "\r\n");
            }
            fclose($fp);
        } else {
            return false;
        }
        return true;
    }
}
