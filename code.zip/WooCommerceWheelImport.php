<?php
/**
 * possible plugin with WooCommerce hooks to remove products that are not on the update sheet.
 *
 *
    add_action( 'woocsv_start_import', 'action_woocsv_start_import', 10, 0 );

    function action_woocsv_start_import(){
        set_transient('namespace_skus_in_csv',array(),0);
    }

    add_filter( 'woocsv_get_product_id', 'filter_woocsv_get_product_id', 10, 2 );
    function filter_woocsv_get_product_id( $product_id, $sku ) {
        $skus = get_transient('namespace_skus_in_csv');
        $skus[] = $sku;
        set_transient('namespace_skus_in_csv',$ids,0);
        return $product_id;
    }

    add_action( 'woocsv_after_save', 'action_woocsv_after_save', 10, 1 );

    function action_woocsv_after_save( $instance ) {
        $skus = get_transient('namespace_skus_in_csv');
        delete_transient('namespace_skus_in_csv');
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1
        );
        $loop = new WP_Query( $args );
        if ( $loop->have_posts() ){
            while ( $loop->have_posts() ){
                $loop->the_post();
                global $product;
                $sku = $product->get_sku();
                if(!array_search($sku, $skus)){
                    wp_delete_post(get_the_ID());
                }
            }
        }
        wp_reset_postdata();
    }
 */
namespace App\Http\Controllers\Api;

//use App\AbstractClasses\WooFields;

class WooCommerceWheelImport {
    /**
     * @var array
     *
     * Definition
     *
     * position == where it is in the list 0,1,2....
     *
     * attribute_1_name === size
     */
    /** ['type'=>'variable', 'sku'=>'', 'name'=>'', 'published'=>'', 'is_featured'=>'', 'visibility_in_catalog'=>'',
    'short_description'=>'', 'in_stock'=> '', 'stock'=>'', 'weight'=>'', 'length'=>'', 'width'=>'', 'height'=>'',
    'regular_price'=>'', 'categories'=>'RIMS', 'images'=>'','parent'=>'Parent',
    'attribute_1_name'=>'size', 'attribute_1_value'=>'1', 'attribute_1_global'=>1, 'attribute_1_visible'=> 1,
    'attribute_2_name'=>'Bolt Pattern', 'attribute_2_value'=>'', 'attribute_2_global'=>1, 'attribute_2_visible'=> 1,
    'attribute_3_name'=>'Rim Offset', 'attribute_3_value'=>'', 'attribute_3_global'=>1, 'attribute_3_visible'=> 1,
    'attribute_4_name'=>'Lug Count', 'attribute_4_value'=>'', 'attribute_4_global'=>1, 'attribute_4_visible'=> 1,
    'attribute_5_name'=>'Hub Bore', 'attribute_5_value'=>'', 'attribute_5_global'=>1, 'attribute_5_visible'=> 1,
    'attribute_6_name'=>'Load Rating', 'attribute_6_value'=>'', 'attribute_6_global'=>1, 'attribute_6_visible'=> 1,
    'attribute_7_name'=>'Finish', 'attribute_7_value'=>'', 'attribute_7_global'=>1, 'attribute_7_visible'=> 1,
    'price'=>'', 'active'=>'', ]; **/
    private object $wcm_column_names;

    private object $vendor_column_names;

    private object $reference_values;

    // this will be used to define the field for change detection
    // so to create parent / child rows will need something to determine when there is a product change.
    private string $name_field;

    private $wcm_column_names_array = ['Type', 'SKU', 'Name', 'Published', 'Is featured?', 'Visibility in catalog', 'Short description', 'In stock?',
                                        'Stock', 'Weight (lbs)', 'Length (in)', 'Width (in)', 'Height (in)', 'Regular price', 'Categories', 'Images', 'Parent', 'Active',
                                        'Attribute 1 name', 'Attribute 1 value(s)', 'Attribute 1 visible', 'Attribute 1 global',
                                        'Attribute 1 name', 'Attribute 2 value(s)', 'Attribute 2 visible', 'Attribute 2 global',
                                        'Attribute 1 name', 'Attribute 3 value(s)', 'Attribute 3 visible', 'Attribute 3 global',
                                        'Attribute 1 name', 'Attribute 4 value(s)', 'Attribute 4 visible', 'Attribute 4 global',
                                        'Attribute 1 name', 'Attribute 5 value(s)', 'Attribute 5 visible', 'Attribute 5 global',
                                        'Attribute 1 name', 'Attribute 6 value(s)', 'Attribute 6 visible', 'Attribute 6 global',
                                        'Attribute 1 name', 'Attribute 7 value(s)', 'Attribute 7 visible', 'Attribute 7 global',];


    function __construct($vendor){
        // REFERENCE VALUES NEEDED TO CHECK IF IT HAS BEEN SET BY ONE OF THE OTHER FUNCTIONS
        $this->reference_values = new WooFields();
        // VENDORS FIELD NAMES, USED FOR READING HEADING

        $this->vendor_column_names = new WooFields();
        // USED FOR EACH ROW INPUT?
        $this->wcm = new WooFields();
        $this->wcm_column_names = new WooFields();

        $this->set_woo_commerce_column_names();

        // VENDOR NAME MAPPING TO THE FUNCTION NAME
        $this->$vendor();
    }

    private function set_woo_commerce_column_names(): void {
        // here I need to set the wooCommerce column names
        $this->wcm_column_names->type = 'Type';
        $this->wcm_column_names->sku = 'SKU';
        $this->wcm_column_names->name = 'Name';
        $this->wcm_column_names->is_featured = 'Is featured?';
        $this->wcm_column_names->visibility_in_catalog = 'Visibility in catalog';
        $this->wcm_column_names->short_description = 'Short Description'; // this is a multi field column !!! IMPORTANT
        $this->wcm_column_names->in_stock = 'In Stock?';
        $this->wcm_column_names->stock = 'Stock';
        $this->wcm_column_names->weight = 'Shipping Weight';
        $this->wcm_column_names->length = 'Unit Length';
        $this->wcm_column_names->width = 'Unit Width';
        $this->wcm_column_names->height = 'Unit Height';
        $this->wcm_column_names->regular_price = 'Regular Price';
        $this->wcm_column_names->images = 'Images';
        // attribute 1
        $this->wcm_column_names->attribute_1_name = 'Attribute 1 name';
        $this->wcm_column_names->attribute_1_value = 'Attribute 1 value(s)';
        $this->wcm_column_names->attribute_1_visible = 'Attribute 1 visible';
        $this->wcm_column_names->attribute_1_global = 'Attribute 1 global';
        // attribute 2
        $this->wcm_column_names->attribute_2_name = 'Attribute 2 name';
        $this->wcm_column_names->attribute_2_value = 'Attribute 2value(s)';
        $this->wcm_column_names->attribute_2_visible = 'Attribute 2 visible';
        $this->wcm_column_names->attribute_2_global = 'Attribute 2 global';
        // attribute 3
        $this->wcm_column_names->attribute_3_name = 'Attribute 3 name';
        $this->wcm_column_names->attribute_3_value = 'Attribute 3 value(s)';
        $this->wcm_column_names->attribute_3_visible = 'Attribute 3 visible';
        $this->wcm_column_names->attribute_3_global = 'Attribute 3 global';
        // attribute 4
        $this->wcm_column_names->attribute_4_name = 'Attribute 4 name';
        $this->wcm_column_names->attribute_4_value = 'Attribute 4 value(s)';
        $this->wcm_column_names->attribute_4_visible = 'Attribute 4 visible';
        $this->wcm_column_names->attribute_4_global = 'Attribute 4 global';
        // attribute 5
        $this->wcm_column_names->attribute_5_name = 'Attribute 5 name';
        $this->wcm_column_names->attribute_5_value = 'Attribute 5 value(s)';
        $this->wcm_column_names->attribute_5_visible = 'Attribute 5 visible';
        $this->wcm_column_names->attribute_5_global = 'Attribute 5 global';
        // attribute 6
        $this->wcm_column_names->attribute_6_name = 'Attribute 6 name';
        $this->wcm_column_names->attribute_6_value = 'Attribute 6 value(s)';
        $this->wcm_column_names->attribute_6_visible = 'Attribute 6 visible';
        $this->wcm_column_names->attribute_6_global = 'Attribute 6 global';
        // attribute 7
        $this->wcm_column_names->attribute_7_name = 'Attribute 7 name';
        $this->wcm_column_names->attribute_7_value = 'Attribute 7 value(s)';
        $this->wcm_column_names->attribute_7_visible = 'Attribute 7 visible';
        $this->wcm_column_names->attribute_7_global = 'Attribute 7 global';
    }

    /**
     *  USE IF !== DEFAULT VALUE && NOT NULL IN THE LOOP TO POPULATE THE CSV OUTPUT FILE
     *
     *   ----------------->>>> ATD COLUMN NAMES   <<<<<<<<<---------------------
     */
    private function atd($is_update = true): void {
        $this->vendor_column_names->sku = 'Supplier # in Z';
        $this->vendor_column_names->name = 'Brand Style';                  // this is a multi field column !!! IMPORTANT
        $this->vendor_column_names->weight = 'Shipping Weight';
        $this->vendor_column_names->length = 'Unit Length';
        $this->vendor_column_names->width = 'Unit Width';
        $this->vendor_column_names->height = 'Unit Height';
        $this->vendor_column_names->regular_price = 'MAP Price';
        $this->vendor_column_names->active = 'Status (US)';
        $this->vendor_column_names->images = $is_update ? '' : 'Image File';
        $this->vendor_column_names->attribute_1_value = 'Size'; // size
        $this->vendor_column_names->attribute_2_value = 'Bolt Pattern'; // Bolt Pattern
        $this->vendor_column_names->attribute_3_value = 'Offset'; // Rim Offset
        $this->vendor_column_names->attribute_4_value = 'Lug Ct'; // Lug Count
        $this->vendor_column_names->attribute_5_value = 'Hub Bore'; // Hub Bore
        $this->vendor_column_names->attribute_6_value = 'Load Rating'; // load rating
        $this->vendor_column_names->attribute_7_value = 'Finish Name'; // finish

        $this->name_field = 'Brand Style';
    }
    /**
     *  USE IF !== DEFAULT VALUE && NOT NULL IN THE LOOP TO POPULATE THE CSV OUTPUT FILE
     *
     *   ----------------->>>> WHEELPROS COLUMN NAMES   <<<<<<<<<---------------------
     */
    private function wheelpros($is_update = false): void {
        $this->vendor_column_names->sku = 'Supplier';
        $this->vendor_column_names->name = 'Brand, Brand Style'; // this is a multi field column !!! IMPORTANT
        $this->vendor_column_names->weight = 'Shipping Weight';
        $this->vendor_column_names->length = 'Unit Length';
        $this->vendor_column_names->width = 'Unit Width';
        $this->vendor_column_names->height = 'Unit Height';
        $this->vendor_column_names->regular_price = 'MAP Price';
        $this->vendor_column_names->active = 'Status (US)';
        $this->vendor_column_names->images = $is_update ? '' : 'Image File';
        $this->vendor_column_names->attribute_1_name = '';
        $this->vendor_column_names->attribute_2_value = '';
        $this->vendor_column_names->attribute_3_value = '';
        $this->vendor_column_names->attribute_4_value = '';
        $this->vendor_column_names->attribute_5_value = '';
        $this->vendor_column_names->attribute_6_value = '';
        $this->vendor_column_names->attribute_7_value = '';

        $this->name_field = 'Brand Style';
    }
    /**
     *  USE IF !== DEFAULT VALUE && NOT NULL IN THE LOOP TO POPULATE THE CSV OUTPUT FILE
     *
     *   ----------------->>>> AXE WHEELS COLUMN NAMES   <<<<<<<<<---------------------
     */
    private function axewheels($is_update = false): void {
        $this->vendor_column_names->sku = 'Supplier # in Z';
        $this->vendor_column_names->name = 'Brand, Brand Style'; // this is a multi field column !!! IMPORTANT
        $this->vendor_column_names->weight = 'Shipping Weight';
        $this->vendor_column_names->length = 'Unit Length';
        $this->vendor_column_names->width = 'Unit Width';
        $this->vendor_column_names->height = 'Unit Height';
        $this->vendor_column_names->regular_price = 'MAP Price';
        $this->vendor_column_names->active = 'Status (US)';
        $this->vendor_column_names->images = $is_update ? '' : 'Image File';
        $this->vendor_column_names->attribute_1_value = '';
        $this->vendor_column_names->attribute_2_value = '';
        $this->vendor_column_names->attribute_3_value = '';
        $this->vendor_column_names->attribute_4_value = '';
        $this->vendor_column_names->attribute_5_value = '';
        $this->vendor_column_names->attribute_6_value = '';
        $this->vendor_column_names->attribute_7_value = '';

        $this->name_field = 'Brand Style';
    }

    final function get_wcm_column_names(): object {
        return $this->wcm_column_names;
    }

    /**
     * @desc return column mapping list
     *
     * @return object
     */
    final function get_vendor_column_names(): object {
        //woocommerce column mapping
        return $this->vendor_column_names;
    }

    final function get_woocommerce_name_array(): array {
        return $this->wcm_column_names_array;
    }

    /**
     * @desc use to determine if a value has been set
     *
     * @param string $column_id
     * @param string $value
     * @return bool
     */
    final function has_set_value(string $column_id, string $value): bool {
        return !($this->reference_values->$column_id === $value);
    }

    /**
     * @desc this is the product name used as reference to check if product changes in loop
     *
     * @return string
     */
    final function get_reference_name_field(): string {
        return $this->name_field;
    }

}
